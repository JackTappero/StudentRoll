import java.util.ArrayList;
import java.util.Comparator;

public class MergeSortStudent {

    public static void mergeSort(ArrayList<Student> list, Comparator<Student> comparator) {
        if (list.size() <= 1) return;

        int mid = list.size() / 2;
        ArrayList<Student> left = new ArrayList<>(list.subList(0, mid));
        ArrayList<Student> right = new ArrayList<>(list.subList(mid, list.size()));

        mergeSort(left, comparator);
        mergeSort(right, comparator);

        merge(list, left, right, comparator);
    }

    private static void merge(ArrayList<Student> result, ArrayList<Student> left,
                              ArrayList<Student> right, Comparator<Student> comparator) {
        int i = 0, j = 0, k = 0;

        while (i < left.size() && j < right.size()) {
            if (comparator.compare(left.get(i), right.get(j)) <= 0) {
                result.set(k++, left.get(i++));
            } else {
                result.set(k++, right.get(j++));
            }
        }

        while (i < left.size()) {
            result.set(k++, left.get(i++));
        }

        while (j < right.size()) {
            result.set(k++, right.get(j++));
        }
    }

    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();

        students.add(new Student(104, "Alice", "NY"));
        students.add(new Student(102, "Bob", "LA"));
        students.add(new Student(108, "Charlie", "Chicago"));
        students.add(new Student(101, "David", "Houston"));
        students.add(new Student(107, "Eve", "Seattle"));
        students.add(new Student(106, "Frank", "Boston"));
        students.add(new Student(103, "Grace", "Denver"));
        students.add(new Student(109, "Hannah", "Phoenix"));
        students.add(new Student(105, "Ivan", "Miami"));
        students.add(new Student(110, "Jane", "Dallas"));

        // Custom Comparator to sort by roll number
        Comparator<Student> rollNoComparator = new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return Integer.compare(s1.rollno, s2.rollno);
            }
        };

        System.out.println("Before Sorting:");
        for (Student s : students) {
            System.out.println(s);
        }

        mergeSort(students, rollNoComparator);

        System.out.println("\nAfter Sorting by Roll No:");
        for (Student s : students) {
            System.out.println(s);
        }
    }
}
